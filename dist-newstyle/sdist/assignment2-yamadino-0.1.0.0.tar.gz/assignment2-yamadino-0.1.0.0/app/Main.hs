{-# LANGUAGE OverloadedStrings #-}

module Main where

import Text.CSV
import qualified Data.ByteString.Lazy as BL
import Data.Csv
import Data.Vector (Vector)
import qualified Data.Vector as V
import Data.Maybe (fromMaybe)
import Data.List (maximumBy)
import Data.Ord (comparing)

data Hospital = Hospital
  { state :: !String
  , beds  :: !Int
  } deriving (Show)

instance FromNamedRecord Hospital where
  parseNamedRecord r = Hospital <$> r .: "state" <*> r .: "beds"

main :: IO ()
main = do
  csvData <- BL.readFile "hospital.csv"
  case decodeByName csvData of
    Left err -> putStrLn err
    Right (_, v) -> print $ stateWithMostBeds v

stateWithMostBeds :: Vector Hospital -> String
stateWithMostBeds = fst . maximumBy (comparing snd) . aggregateBeds

aggregateBeds :: Vector Hospital -> [(String, Int)]
aggregateBeds = V.foldr (\h acc -> addBeds (state h) (beds h) acc) []

addBeds :: String -> Int -> [(String, Int)] -> [(String, Int)]
addBeds st b [] = [(st, b)]
addBeds st b ((s, n):xs)
  | st == s   = (s, n + b) : xs
  | otherwise = (s, n) : addBeds st b xs
